#!/bin/sh
# stand-in for upstream's logging helper
